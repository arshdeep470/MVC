using System.ComponentModel.DataAnnotations;
using MVCMarket.Models;
using MVCMarket.ViewModels.Validations;

namespace MVCMarket.ViewModels
{
    public class SalesViewModel
    {
        public IEnumerable<Category> Categories { get; set; } = new List<Category>();
        public int SelectedCategoryId {get; set;}

        public int SelectedProductId { get; set; }

        [Display(Name = "Quantity")]
        [Range(1, int.MaxValue)]
        [SalesViewModel_EnsureProperQuantity]
        public int QuantityToSell { get; set; }
    }
}