using MVCMarket.Models;

namespace MVCMarket.ViewModels
{
    public class ProductViewModel
    {
        public IEnumerable<Category> Categories { get; set; } = new List<Category>();
        public Product Product { get; set; } = new Product();
    }
}

// Empty categories list and product list has been made